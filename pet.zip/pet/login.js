var express=require("express")
var bodyParser=require("body-parser")
var mongoose=require("mongoose")

const  app=express()
app.use(bodyParser.json())
app.use(express.static('public'))
app.use(bodyParser.urlencoded({
    extended:true
}))
mongoose.connect('mongodb://localhost:27017')
var db=mongoose.connection
db.on('error',() => console.log("error in connection to database"))
db.once('open',()=>console.log("connected to database"))

app.post("/login",(req,res)=> {
   
    var email=req.body.email 
    var password=req.body.password

    var data={
        "name":name,
        "age":age,
        "email":email,
        "phone":phone,
        "gender":gender,
        "password":password

    }

    db.collection('users').insertOne(data,(err,collection)=>{
        if(err){
            throw err;

        }
        console.log("Record Inserted Successfully")
    })
    return res.redirect('login.html')
})
app.get("/",(req,res) => {
    res.set({
        "Allow-access-Allow-Origin":'*'
    })
    return res.redirect('login.html')
}).listen(3000)

console.log("listening on port 3000")